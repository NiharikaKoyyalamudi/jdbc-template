package com.nkxgen.spring.jdbc.dao;

import java.util.List;

import com.nkxgen.spring.jdbc.model.Employee;

public interface EmpDAO {
	static Employee getEmployeeByNo(Integer eno) {
		// TODO Auto-generated method stub
		return null;
	}

	List<Employee> getAllEmployees();

	boolean deleteEmployee(Employee e);

	boolean updateEmployee(Employee e);

	boolean createEmployee(Employee e);
}
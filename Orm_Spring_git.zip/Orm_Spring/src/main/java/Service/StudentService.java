package Service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import DAO.StudentDAO;
import Entity.Student;

@Service
@Transactional
public class StudentService {

    @Autowired
    private StudentDAO studentDAO;

    public void save(Student student) {
        studentDAO.save(student);
    }

    public Student findById(Long id) {
        return studentDAO.findById(id);
    }

    public List<Student> findAll() {
        return studentDAO.findAll();
    }

    public void update(Student student) {
        studentDAO.update(student);
    }

    public void delete(Student student) {
        studentDAO.delete(student);
    }
}

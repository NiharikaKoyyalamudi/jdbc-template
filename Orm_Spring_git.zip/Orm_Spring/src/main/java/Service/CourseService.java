package Service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import DAO.CourseDAO;

import Entity.Course;
@Service
@Transactional
public class CourseService {

    @Autowired
    private CourseDAO courseDAO;

    public void save(Course course) {
        courseDAO.save(course);
    }

    public Course findById(Long id) {
        return courseDAO.findById(id);
    }

    public List<Course> findAll() {
        return courseDAO.findAll();
    }

    public void update(Course course) {
        courseDAO.update(course);
    }

    public void delete(Course course) {
        courseDAO.delete(course);
    }
}
